import {
  mysqlTable, mysqlEnum, serial, varchar, timestamp, bigint, double, int,
} from 'drizzle-orm/mysql-core'

export const players = mysqlTable('players', {
  id: serial('id').primaryKey(),
  clientKey: varchar('client_key', { length: 80 }).notNull().unique(),
  name: varchar('name', { length: 40 }).notNull().default('Космонавт'),
  balance: double('balance').notNull().default(2500),
  lastBonus: timestamp('last_bonus'),
  blacklisted: int('blacklisted').notNull().default(0),
  username: varchar('username', { length: 80 }),
  createdAt: timestamp('created_at').notNull().defaultNow(),
})

export const inventoryItems = mysqlTable('inventory_items', {
  id: serial('id').primaryKey(),
  playerId: bigint('player_id', { mode: 'number', unsigned: true }).notNull(),
  giftId: varchar('gift_id', { length: 50 }).notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
})

export const diceLobbies = mysqlTable('dice_lobbies', {
  id: serial('id').primaryKey(),
  creatorId: bigint('creator_id', { mode: 'number', unsigned: true }).notNull(),
  opponentId: bigint('opponent_id', { mode: 'number', unsigned: true }),
  bet: double('bet').notNull(),
  status: mysqlEnum('status', ['waiting', 'finished', 'cancelled']).notNull().default('waiting'),
  creatorRoll: int('creator_roll'),
  opponentRoll: int('opponent_roll'),
  winnerId: bigint('winner_id', { mode: 'number', unsigned: true }),
  isBot: int('is_bot').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow().onUpdateNow(),
})

export const rocketRounds = mysqlTable('rocket_rounds', {
  id: serial('id').primaryKey(),
  playerId: bigint('player_id', { mode: 'number', unsigned: true }).notNull(),
  bet: double('bet').notNull(),
  crashPoint: double('crash_point').notNull(),
  status: mysqlEnum('status', ['running', 'cashed', 'crashed']).notNull().default('running'),
  payout: double('payout').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow(),
})

export const gameEvents = mysqlTable('game_events', {
  id: serial('id').primaryKey(),
  playerId: bigint('player_id', { mode: 'number', unsigned: true }).notNull(),
  game: varchar('game', { length: 20 }).notNull(),
  bet: double('bet').notNull(),
  payout: double('payout').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow(),
})

export const crashRounds = mysqlTable('crash_rounds', {
  id: serial('id').primaryKey(),
  status: mysqlEnum('status', ['betting', 'running', 'crashed']).notNull().default('betting'),
  crashPoint: double('crash_point').notNull(),
  startsAt: timestamp('starts_at').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
})

export const crashBets = mysqlTable('crash_bets', {
  id: serial('id').primaryKey(),
  roundId: bigint('round_id', { mode: 'number', unsigned: true }).notNull(),
  playerId: bigint('player_id', { mode: 'number', unsigned: true }).notNull(),
  bet: double('bet').notNull(),
  payout: double('payout').notNull().default(0),
  cashoutAt: double('cashout_at'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
})

export const appSettings = mysqlTable('app_settings', {
  key: varchar('key', { length: 40 }).primaryKey(),
  value: varchar('value', { length: 255 }).notNull(),
})

export const paymentRequests = mysqlTable('payment_requests', {
  id: serial('id').primaryKey(),
  playerId: bigint('player_id', { mode: 'number', unsigned: true }).notNull(),
  type: mysqlEnum('type', ['deposit', 'withdraw']).notNull(),
  amount: double('amount').notNull(),
  status: mysqlEnum('status', ['pending', 'approved', 'rejected']).notNull().default('pending'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
})

export type Player = typeof players.$inferSelect
export type InventoryItemRow = typeof inventoryItems.$inferSelect
export type DiceLobby = typeof diceLobbies.$inferSelect
export type RocketRound = typeof rocketRounds.$inferSelect
