import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowLeftRight, ArrowUpRight, Box, Check, ChevronRight, CircleDollarSign,
  Dices, Gamepad2, Gem, Gift as GiftIcon, History, Rocket, ShieldCheck, Sparkles, Star, User,
  Users, Wallet, X, Zap,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { gameCases, giftMap, type GameCase, type Gift } from '@contracts/gifts'
import './App.css'

type Tab = 'games' | 'cases' | 'inventory' | 'profile'
type Notify = (message: string) => void
type InventoryEntry = { id: number; gift: Gift; createdAt: Date }
type CommonProps = { clientKey: string; playerId: number; balance: number; inventory: InventoryEntry[]; refresh: () => void; notify: Notify }

const money = (value: number) => new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 }).format(value)
const chanceText = (value: number) => `${(value * 100).toFixed(value < 0.1 ? 1 : 0).replace('.', ',')}%`
let currentStarRate = 1.3
const giftRub = (gift: Gift) => gift.id === 'cash' ? gift.rub : Math.round(gift.stars * currentStarRate)

function getClientKey() {
  const telegramId = (window as unknown as { Telegram?: { WebApp?: { initDataUnsafe?: { user?: { id?: number } } } } }).Telegram?.WebApp?.initDataUnsafe?.user?.id
  if (telegramId) return `tg:${telegramId}`
  const existing = localStorage.getItem('nebula-player-key')
  if (existing) return existing
  const created = crypto.randomUUID()
  localStorage.setItem('nebula-player-key', created)
  return created
}

function GiftArt({ gift, small = false }: { gift: Gift; small?: boolean }) {
  return <div className={`gift-art gift-${gift.rarity} ${small ? 'small' : ''}`}>{gift.id === 'cash' ? <div className="cash-prize"><CircleDollarSign size={small ? 34 : 62} /><strong>{money(giftRub(gift))} ₽</strong></div> : <img src={gift.image} alt={gift.name} draggable={false} />}</div>
}

function Modal({ children, onClose, locked = false, label, wide = false }: { children: React.ReactNode; onClose: () => void; locked?: boolean; label: string; wide?: boolean }) {
  useEffect(() => {
    const handler = (event: KeyboardEvent) => { if (event.key === 'Escape' && !locked) onClose() }
    document.addEventListener('keydown', handler)
    document.body.style.overflow = 'hidden'
    return () => { document.removeEventListener('keydown', handler); document.body.style.overflow = '' }
  }, [locked, onClose])
  return <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget && !locked) onClose() }}>
    <section className={`modal ${wide ? 'modal-wide' : ''}`} role="dialog" aria-modal="true" aria-label={label}>
      <button className="icon-button modal-close" onClick={onClose} disabled={locked} aria-label="Закрыть"><X size={20} /></button>
      {children}
    </section>
  </div>
}

function BetControls({ bet, setBet, disabled = false, min = 10 }: { bet: string; setBet: (n: string) => void; disabled?: boolean; min?: number }) {
  return <div className="bet-block">
    <label htmlFor="bet">Размер ставки</label>
    <div className="bet-input"><input id="bet" aria-label="Размер ставки" type="number" min={min} step="10" value={bet} disabled={disabled} onChange={(e) => setBet(e.target.value.replace(/^0+(?=\d)/, ''))} /><span>₽</span></div>
    <div className="bet-presets">{[50, 100, 250, 500].map(n => <button key={n} disabled={disabled} onClick={() => setBet(String(n))}>{n}</button>)}</div>
  </div>
}

function UpgradeGame({ clientKey, balance, inventory, refresh, notify }: CommonProps) {
  const [bet, setBet] = useState('100')
  const [mode, setMode] = useState<'cash' | 'item'>('cash')
  const [itemId, setItemId] = useState<number | null>(null)
  const [multiplier, setMultiplier] = useState(2)
  const [spinning, setSpinning] = useState(false)
  const [rotation, setRotation] = useState(0)
  const [result, setResult] = useState<'win' | 'lose' | null>(null)
  const [awarded, setAwarded] = useState<Gift | null>(null)
  const betValue = Number(bet) || 0
  const chance = 0.95 / multiplier
  const selectedItem = inventory.find(item => item.id === itemId) || null
  const stakeValue = mode === 'item' ? (selectedItem ? giftRub(selectedItem.gift) : 0) : betValue
  const target = useMemo(() => {
    const payout = stakeValue * multiplier
    return Object.values(giftMap).filter(gift => gift.id !== 'cash').reduce((best, gift) => Math.abs(giftRub(gift) - payout) < Math.abs(giftRub(best) - payout) ? gift : best, giftMap.cake)
  }, [stakeValue, multiplier])
  const mutation = trpc.game.upgrade.useMutation()
  const itemMutation = trpc.game.upgradeItem.useMutation()
  const play = async () => {
    if (mode === 'item' && !selectedItem) return notify('Выберите подарок из инвентаря')
    if (mode === 'cash' && (betValue < 10 || betValue > balance)) return notify(betValue > balance ? 'Недостаточно средств' : 'Минимальная ставка — 10 ₽')
    setSpinning(true); setResult(null)
    try {
      const response = mode === 'item' && selectedItem
        ? await itemMutation.mutateAsync({ clientKey, itemId: selectedItem.id, multiplier, targetId: target.id })
        : await mutation.mutateAsync({ clientKey, bet: betValue, multiplier })
      const yellowDegrees = chance * 360
      const yellowStart = 180 - yellowDegrees / 2
      const landing = response.win ? yellowStart + Math.random() * yellowDegrees : (yellowStart + yellowDegrees + Math.random() * (360 - yellowDegrees)) % 360
      setRotation(r => r + 1800 + (360 - landing))
      window.setTimeout(() => {
        setSpinning(false); setResult(response.win ? 'win' : 'lose'); setAwarded(response.win && mode === 'item' ? target : null); refresh()
        if (response.win) notify(mode === 'item' ? `Получен ${target.name}` : `Улучшение удалось · +${money(betValue * multiplier)} ₽`)
      }, 1900)
    } catch (error) { setSpinning(false); notify(error instanceof Error ? error.message : 'Ошибка игры') }
  }
  return <div className="upgrade-lab">
    <div className="upgrade-mode"><button className={mode === 'cash' ? 'active' : ''} disabled={spinning} onClick={() => { setMode('cash'); setResult(null) }}>Рубли</button><button className={mode === 'item' ? 'active' : ''} disabled={spinning} onClick={() => { setMode('item'); setResult(null) }}><Gem size={15} /> NFT из инвентаря</button></div>
    <div className="upgrade-meta"><span><Zap size={14} /> LIVE</span><strong>Шанс улучшения <b>{chanceText(chance)}</b></strong><ShieldCheck size={16} /></div>
    <div className={`upgrade-orbit ${spinning ? 'is-spinning' : ''} ${result || ''}`} style={{ '--yellow': `${chance * 360}deg`, '--yellow-start': `${180 - chance * 180}deg` } as React.CSSProperties}>
      <div className="upgrade-arrow" style={{ transform: `rotate(${rotation}deg)` }}><i /></div>
      <div className="upgrade-ring" />
      <div className="upgrade-target"><GiftArt gift={target} /><span>{target.name}</span><strong>{money(target.rub)} ₽</strong><small>рыночная цена</small></div>
      <div className="orbit-star"><Star size={17} fill="currentColor" /></div>
    </div>
    <div className="upgrade-exchange">
      <div><span>Ваша ставка</span><strong>{mode === 'item' ? selectedItem?.gift.name || 'Выберите NFT' : `${money(betValue)} ₽`}</strong></div><ArrowLeftRight size={20} />
      <div><span>Можете получить</span><strong>{target.name} · {money(target.rub)} ₽</strong></div>
    </div>
    <div className="quick-multipliers">{[2, 4, 8].map(n => <button key={n} className={multiplier === n ? 'active' : ''} disabled={spinning} onClick={() => { setMultiplier(n); setResult(null) }}>×{n}</button>)}</div>
    <div className="multiplier-slider">
      <div><span>Множитель</span><strong>×{multiplier.toFixed(multiplier % 1 ? 1 : 0)}</strong></div>
      <input aria-label="Множитель апгрейда" type="range" min="2" max="50" step="1" value={multiplier} disabled={spinning} onChange={e => { setMultiplier(Number(e.target.value)); setResult(null) }} style={{ '--range': `${(multiplier - 2) / 48 * 100}%` } as React.CSSProperties} />
      <div className="range-labels"><span>×2</span><span>×25</span><span>×50</span></div>
    </div>
    {mode === 'cash' ? <BetControls bet={bet} setBet={setBet} disabled={spinning} /> : <div className="upgrade-inventory">{inventory.length === 0 ? <p>Инвентарь пуст — сначала откройте NFT-кейс.</p> : inventory.map(item => <button key={item.id} disabled={spinning} className={itemId === item.id ? 'active' : ''} onClick={() => { setItemId(item.id); setResult(null) }}><GiftArt gift={item.gift} small /><span>{item.gift.name}</span><strong>{money(giftRub(item.gift))} ₽</strong></button>)}</div>}
    <button className="primary-action upgrade-action" disabled={spinning} onClick={play}>{spinning ? 'Стрелка вращается…' : result === 'win' ? 'Улучшить ещё' : 'Улучшить'} <ArrowUpRight size={18} /></button>
    {result && <div className={`upgrade-outcome ${result}`}>{result === 'win' ? mode === 'item' && awarded ? `Стрелка в жёлтом — ${awarded.name}, ${money(awarded.rub)} ₽` : `Стрелка в жёлтом — выигрыш ${money(betValue * multiplier)} ₽` : 'Стрелка вне жёлтого сектора'}</div>}
  </div>
}

function NebulaRocket() {
  return <svg className="nebula-rocket" viewBox="0 0 100 180" aria-label="Фирменная ракета Nebula" role="img">
    <defs><linearGradient id="rocketBody" x1="0" x2="1"><stop stopColor="#aab4c7"/><stop offset=".45" stopColor="#fff"/><stop offset="1" stopColor="#68758e"/></linearGradient><linearGradient id="rocketFire" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#fff"/><stop offset=".3" stopColor="#d9ff43"/><stop offset="1" stopColor="#ff7a18" stopOpacity="0"/></linearGradient></defs>
    <path className="rocket-flame" d="M38 139 Q50 179 62 139 L57 126 H43Z" fill="url(#rocketFire)"/>
    <path d="M29 102 L15 137 L37 126 M71 102 L85 137 L63 126" fill="#8d99af" stroke="#e7ecf5" strokeWidth="2"/>
    <path d="M50 5 C31 23 27 51 29 116 L38 137 H62 L71 116 C73 51 69 23 50 5Z" fill="url(#rocketBody)" stroke="#f8fbff" strokeWidth="2"/>
    <path d="M50 5 C40 15 35 25 32 38 H68 C65 25 60 15 50 5Z" fill="#d9ff43"/>
    <circle cx="50" cy="60" r="14" fill="#111827" stroke="#d9ff43" strokeWidth="4"/><circle cx="46" cy="55" r="5" fill="#8ee9ff" opacity=".75"/>
    <path d="M34 98 H66" stroke="#77839a" strokeWidth="2"/><path d="M39 128 H61" stroke="#222b3d" strokeWidth="6"/>
    <g transform="translate(50 88)"><circle r="10" fill="#121827"/><path d="M-5 4 L0-6 L5 4 M-3 0 H3" fill="none" stroke="#d9ff43" strokeWidth="2" strokeLinecap="round"/></g>
  </svg>
}

function RocketGame({ clientKey, refresh, notify }: CommonProps) {
  const [bet, setBet] = useState('100')
  const [tick, setTick] = useState(0)
  const startMutation = trpc.game.rocketStart.useMutation()
  const cashMutation = trpc.game.rocketCashout.useMutation()
  const statusQuery = trpc.game.rocketStatus.useQuery({ clientKey }, { refetchInterval: 400, retry: false })
  const data = statusQuery.data
  useEffect(() => { const timer = setInterval(() => setTick(value => value + 1), 100); return () => clearInterval(timer) }, [])
  const phase = data?.status || 'betting'
  const mult = data?.multiplier || 1
  const myBet = data?.myBet
  const countdown = data ? Math.max(0, Math.ceil((data.startsAt.getTime() - Date.now()) / 1000)) : 0
  void tick
  const numericBet = Number(bet) || 0
  const start = async () => {
    if (numericBet < 10) return notify('Минимальная ставка — 10 ₽')
    try { await startMutation.mutateAsync({ clientKey, bet: numericBet }); refresh(); await statusQuery.refetch() }
    catch (error) { notify(error instanceof Error ? error.message : 'Не удалось сделать ставку') }
  }
  const cashOut = async () => {
    if (!data) return
    try { const response = await cashMutation.mutateAsync({ clientKey, roundId: data.roundId }); refresh(); await statusQuery.refetch(); notify(`Вы забрали ${money(response.payout)} ₽`) }
    catch (error) { notify(error instanceof Error ? error.message : 'Раунд уже завершён'); await statusQuery.refetch() }
  }
  const scene = mult >= 16 ? 'nebula' : mult >= 8 ? 'mars' : mult >= 4 ? 'moon' : mult >= 2 ? 'earth' : 'night'
  return <>
    <div className={`rocket-stage space-${scene} ${phase}`}>
      <div className="star-field" /><div className="star-field stars-two" /><div className="space-planet"><span /></div>
      <div className="space-label">ОБЩИЙ РАУНД · {scene === 'night' ? 'НОЧНОЕ НЕБО' : scene === 'earth' ? 'ЗЕМЛЯ' : scene === 'moon' ? 'ЛУНА' : scene === 'mars' ? 'МАРС' : 'ТУМАННОСТЬ'}</div>
      <div className="flight-path"><NebulaRocket /></div>
      <div className="rocket-readout">{phase === 'betting' ? <><strong>{countdown}</strong><span>до запуска</span></> : phase === 'crashed' ? <><strong>КРАШ</strong><span>{mult.toFixed(2)}×</span></> : <strong>{mult.toFixed(2)}×</strong>}</div>
      <span className="stage-hint">{phase === 'betting' ? 'Ставки принимаются у всех игроков' : phase === 'running' ? 'Заберите выигрыш до общего краша' : 'Скоро начнётся новый раунд'}</span>
    </div>
    <BetControls bet={bet} setBet={setBet} disabled={phase !== 'betting' || !!myBet} />
    {phase === 'running' && myBet && !myBet.cashoutAt ? <button className="primary-action cashout" onClick={cashOut} disabled={cashMutation.isPending}>Забрать {money(myBet.bet * mult)} ₽</button> : <button className="primary-action" onClick={start} disabled={phase !== 'betting' || !!myBet || startMutation.isPending}>{myBet ? myBet.cashoutAt ? `Забрано на ×${myBet.cashoutAt.toFixed(2)}` : `Ставка ${money(myBet.bet)} ₽ принята` : phase === 'betting' ? 'Сделать ставку' : 'Ждём следующий раунд'} <Rocket size={18} /></button>}
    <div className="rocket-bets-heading"><span>Игроков {data?.bets.length || 0}</span><strong>Банк {money(data?.bets.reduce((sum, entry) => sum + entry.bet, 0) || 0)} ₽</strong></div>
    <div className="rocket-bets">{data?.bets.map(entry => <div key={entry.id} className={entry.cashoutAt ? 'cashed' : ''}><span className="bet-avatar">{entry.name.slice(0, 1)}</span><span><strong>{entry.name}</strong><small>{money(entry.bet)} ₽</small></span>{entry.cashoutAt ? <><b>×{entry.cashoutAt.toFixed(2)}</b><strong>{money(entry.payout)} ₽</strong></> : <span>{phase === 'crashed' ? 'Не успел' : 'В игре'}</span>}</div>)}{!data?.bets.length && <p>Ставок пока нет — ваш раунд появится здесь.</p>}</div>
  </>
}

function DiceGame({ clientKey, playerId, refresh, notify }: CommonProps) {
  const [bet, setBet] = useState('100')
  const lobbiesQuery = trpc.game.diceLobbies.useQuery({ clientKey }, { refetchInterval: 2500 })
  const createMutation = trpc.game.createDiceLobby.useMutation()
  const joinMutation = trpc.game.joinDiceLobby.useMutation()
  const cancelMutation = trpc.game.cancelDiceLobby.useMutation()
  const botMutation = trpc.game.joinDiceBot.useMutation()
  const run = async (action: () => Promise<unknown>, success?: string) => {
    try { await action(); await lobbiesQuery.refetch(); refresh(); if (success) notify(success) }
    catch (error) { notify(error instanceof Error ? error.message : 'Ошибка лобби') }
  }
  const lobbies = lobbiesQuery.data || []
  const myWaiting = lobbies.find(l => l.status === 'waiting' && l.creatorId === playerId)
  return <div className="dice-lobbies">
    <div className="create-lobby"><div><Users size={20} /><span><strong>Создать лобби</strong><small>Ставка от 10 ₽ · победа ×1,9</small></span></div><div className="lobby-create-row"><div className="bet-input"><input aria-label="Ставка лобби" type="number" min="10" value={bet} onChange={e => setBet(e.target.value.replace(/^0+(?=\d)/, ''))} /><span>₽</span></div><button disabled={createMutation.isPending || !!myWaiting} onClick={() => run(() => createMutation.mutateAsync({ clientKey, bet: Number(bet) || 0 }), 'Лобби создано')}>Создать</button></div></div>
    <div className="lobby-list-heading"><span>ОТКРЫТЫЕ ИГРЫ</span><button onClick={() => lobbiesQuery.refetch()}>Обновить</button></div>
    <div className="lobby-list">{lobbies.filter(l => l.status !== 'cancelled').length === 0 ? <div className="lobby-empty"><Dices size={36} /><p>Пока нет игр. Создайте первое лобби.</p></div> : lobbies.filter(l => l.status !== 'cancelled').map(lobby => <article className={`lobby-row ${lobby.status}`} key={lobby.id}>
      <div className="lobby-players"><span>{lobby.creatorName}</span><Dices size={20} /><span>{lobby.opponentName || 'Ожидание…'}</span></div>
      <div className="lobby-info"><strong>{money(lobby.bet)} ₽</strong>{lobby.status === 'waiting' ? <span>Открыто</span> : <span>{lobby.creatorRoll} : {lobby.opponentRoll}{lobby.creatorRoll === lobby.opponentRoll ? ' · ничья' : lobby.isBot && !lobby.winnerId ? ' · победа бота' : ''}</span>}</div>
      {lobby.status === 'waiting' && <div className="lobby-actions">{lobby.creatorId === playerId ? <><button className="bot-button" disabled={botMutation.isPending} onClick={() => run(() => botMutation.mutateAsync({ clientKey, lobbyId: lobby.id }), 'Nebula Bot присоединился к игре')}>Добавить бота</button><button onClick={() => run(() => cancelMutation.mutateAsync({ clientKey, lobbyId: lobby.id }), 'Лобби отменено, ставка возвращена')}>Отменить</button></> : <button className="join" onClick={() => run(() => joinMutation.mutateAsync({ clientKey, lobbyId: lobby.id }))}>Войти</button>}</div>}
    </article>)}</div>
  </div>
}

function CaseOpening({ data, clientKey, refresh, goInventory, onClose, notify }: { data: GameCase } & Omit<CommonProps, 'balance' | 'playerId' | 'inventory'> & { goInventory: () => void; onClose: () => void }) {
  const [phase, setPhase] = useState<'idle' | 'spinning' | 'result'>('idle')
  const [prize, setPrize] = useState<Gift | null>(null)
  const [reel, setReel] = useState<Gift[]>([])
  const mutation = trpc.game.openCase.useMutation()
  const randomGift = () => {
    const total = data.prizes.reduce((sum, p) => sum + p.weight, 0)
    let roll = Math.random() * total
    for (const entry of data.prizes) { roll -= entry.weight; if (roll <= 0) { const gift = giftMap[entry.giftId]; return gift.id === 'cash' ? { ...gift, rub: 5 + Math.floor(Math.random() * data.price * .8) } : gift } }
    return giftMap[data.prizes[0].giftId]
  }
  const open = async () => {
    try {
      const response = await mutation.mutateAsync({ clientKey, caseId: data.id })
      const items = Array.from({ length: 32 }, randomGift); items[27] = response.prize
      setPrize(response.prize); setReel(items); setPhase('spinning'); refresh()
      window.setTimeout(() => setPhase('result'), 3000)
    } catch (error) { notify(error instanceof Error ? error.message : 'Не удалось открыть кейс') }
  }
  return <Modal onClose={onClose} locked={phase === 'spinning'} label={`Кейс ${data.name}`} wide>
    <div className="modal-heading"><span className="eyebrow">NEBULA CASES</span><h2>{data.name}</h2></div>
    {phase === 'idle' && <>
      <div className={`case-detail case-${data.accent}`}><div className="case-detail-art"><Box size={72} /><Sparkles size={25} /></div><span>{data.subtitle}</span><strong>{data.prizes.length} разных призов</strong></div>
      <div className="case-prizes"><h3>Что может выпасть</h3><div>{data.prizes.map(entry => { const gift = giftMap[entry.giftId]; return <article key={entry.giftId}><GiftArt gift={gift} small /><strong>{gift.name}</strong><span><Star size={11} fill="currentColor" /> {money(gift.stars)}</span><small>{chanceText(entry.weight / 100)}</small></article> })}</div></div>
      <button className="primary-action" onClick={open} disabled={mutation.isPending}>Открыть за {money(data.price)} ₽ <Box size={18} /></button>
      <p className="modal-note"><ShieldCheck size={14} /> NFT-подарок сразу попадёт в инвентарь</p>
    </>}
    {phase !== 'idle' && <div className={`case-opening-stage ${phase}`}><div className="case-opening-beam" /><div className="roulette-wrap"><div className="roulette-marker" /><div className={`roulette ${phase === 'spinning' ? 'is-spinning' : 'is-stopped'}`}>{reel.map((gift, i) => <div className={`roulette-item gift-${gift.rarity}`} key={i}><GiftArt gift={gift} small /><strong>{gift.name}</strong><span>{money(giftRub(gift))} ₽</span></div>)}</div></div></div>}
    {phase === 'spinning' && <p className="spin-label"><Sparkles size={16} /> Определяем ваш NFT-подарок…</p>}
    {phase === 'result' && prize && <div className="prize-result"><span className={`rarity-label gift-${prize.rarity}`}>{prize.rarity === 'legendary' ? 'Легендарный' : prize.rarity === 'epic' ? 'Эпический' : prize.rarity === 'rare' ? 'Редкий' : 'Обычный'}</span><GiftArt gift={prize} /><h3>{prize.name}</h3><strong>{money(giftRub(prize))} ₽{prize.id === 'cash' ? '' : ` · ${money(prize.stars)} ★`}</strong><div className="result-actions"><button className="secondary-action" onClick={() => setPhase('idle')}>Ещё кейс</button><button className="primary-action" onClick={prize.id === 'cash' ? onClose : goInventory}>{prize.id === 'cash' ? 'Продолжить' : 'В инвентарь'} <ChevronRight size={18} /></button></div></div>}
  </Modal>
}

export default function App() {
  const [clientKey] = useState(getClientKey)
  const [tab, setTab] = useState<Tab>('games')
  const [game, setGame] = useState<'rocket' | 'upgrade' | 'dice' | null>(null)
  const [activeCase, setActiveCase] = useState<GameCase | null>(null)
  const [toast, setToast] = useState('')
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const stateQuery = trpc.game.state.useQuery({ clientKey })
  const utils = trpc.useUtils()
  const refresh = () => { utils.game.state.invalidate() }
  const notify = (message: string) => { setToast(message); if (toastTimer.current) clearTimeout(toastTimer.current); toastTimer.current = setTimeout(() => setToast(''), 2800) }
  currentStarRate = stateQuery.data?.rates.stars ?? 1.3
  const balance = stateQuery.data?.player.balance ?? 0
  const inventory = stateQuery.data?.inventory ?? []
  const lastBonus = stateQuery.data?.player.lastBonus
  const inventoryValue = inventory.reduce((sum, item) => sum + giftRub(item.gift), 0)
  const stats = stateQuery.data?.stats
  const gameNames: Record<string, string> = { rocket: 'Ракета', upgrade: 'Апгрейд', dice: 'Кости', cases: 'Кейсы' }
  const common: CommonProps = { clientKey, playerId: stateQuery.data?.player.id ?? 0, balance, inventory, refresh, notify }
  const bonusMutation = trpc.game.bonus.useMutation()
  const sellMutation = trpc.game.sellItem.useMutation()
  const claimBonus = async () => {
    try { const response = await bonusMutation.mutateAsync({ clientKey }); refresh(); notify(`Ежедневный бонус: +${response.amount} ₽`) }
    catch (error) { notify(error instanceof Error ? error.message : 'Бонус недоступен') }
  }
  const navigate = (next: Tab) => { setTab(next); setGame(null); setActiveCase(null); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  const navItems = [
    { id: 'games' as Tab, label: 'Игры', icon: Gamepad2 }, { id: 'cases' as Tab, label: 'Кейсы', icon: Box },
    { id: 'inventory' as Tab, label: 'Инвентарь', icon: Gem }, { id: 'profile' as Tab, label: 'Профиль', icon: User },
  ]

  if (stateQuery.isLoading) return <div className="app-loading"><Rocket size={42} /><strong>NEBULA</strong><span>Загружаем игровой профиль…</span></div>
  if (stateQuery.isError) return <div className="app-loading"><ShieldCheck size={42} /><strong>Нет соединения</strong><button className="primary-action" onClick={() => stateQuery.refetch()}>Повторить</button></div>

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => navigate('games')} aria-label="Nebula — на главную"><span className="brand-mark"><Rocket size={21} /></span><span>NEBULA<small>ARCADE</small></span></button>
      <div className="header-actions"><div className="balance"><span><Wallet size={16} /> БАЛАНС</span><strong>{money(balance)} ₽</strong></div></div>
    </header>
    <nav className="desktop-nav" aria-label="Основная навигация">{navItems.map(({ id, label, icon: Icon }) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => navigate(id)}><Icon size={18} />{label}{id === 'inventory' && inventory.length > 0 && <b>{inventory.length}</b>}</button>)}</nav>

    <main>
      {tab === 'games' && <div className="page games-page">
        <section className="welcome"><div><span className="eyebrow"><span className="live-dot" /> ИГРОВОЙ СЕЗОН 01</span><h1>Твоя игра.<br /><em>Твои правила.</em></h1></div><p>Апгрейд до ×50, общие лобби<br className="desktop-only" /> и полёт за пределы Земли.</p></section>
        <section className="game-grid">
          <button className="game-tile rocket-tile" onClick={() => setGame('rocket')}><div className="tile-copy"><span className="game-status">ЗЕМЛЯ · ЛУНА · МАРС</span><h2>Ракета</h2><p>Успей забрать до краша</p><span className="play-link">Играть <ArrowUpRight size={18} /></span></div><div className="rocket-visual"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="planet" /><Rocket size={90} /></div></button>
          <button className="game-tile upgrade-tile" onClick={() => setGame('upgrade')}><div className="tile-copy"><span className="game-status">ОТ ×2 ДО ×50</span><h2>Апгрейд</h2><p>Жёлтый сектор — твой шанс</p><span className="play-link">Играть <ArrowUpRight size={18} /></span></div><div className="mini-wheel"><Zap size={42} /></div></button>
          <button className="game-tile dice-tile" onClick={() => setGame('dice')}><div className="tile-copy"><span className="game-status">ОБЩИЕ ЛОББИ</span><h2>Кости</h2><p>Создай игру от 10 ₽</p><span className="play-link">Играть <ArrowUpRight size={18} /></span></div><Dices className="dice-art" size={94} /></button>
        </section>
        <section className="fair-strip"><ShieldCheck size={22} /><div><strong>Результаты считаются на сервере</strong><span>Баланс, ставки и NFT-инвентарь сохраняются в профиле</span></div><button onClick={() => navigate('profile')}>Профиль <ChevronRight size={16} /></button></section>
      </div>}

      {tab === 'cases' && <div className="page cases-page">
        <section className="section-heading"><div><span className="eyebrow">TELEGRAM GIFTS · 1 ★ = {money(currentStarRate)} ₽</span><h1>NFT-кейсы</h1></div><p>Девять коллекций.<br />NFT и рубли внутри.</p></section>
        <div className="case-grid">{gameCases.map((data, index) => <button className={`case-card case-${data.accent}`} key={data.id} onClick={() => setActiveCase(data)}><span className="case-number">0{index + 1}</span><span className="case-tag">{data.subtitle}</span><div className="case-visual"><div className="case-lid" /><div className="case-body"><Box size={70} /></div><div className="case-glow" /></div><div className="case-info"><h2>{data.name}</h2><span>{data.prizes.length} призов внутри</span><strong>{money(data.price)} ₽ <ArrowUpRight size={20} /></strong></div></button>)}</div>
        <div className="case-note"><GiftIcon size={20} /><span>Редкие NFT выпадают с маленьким шансом — он указан внутри каждого кейса</span></div>
      </div>}

      {tab === 'inventory' && <div className="page inventory-page">
        <section className="section-heading"><div><span className="eyebrow">ТВОЯ NFT-КОЛЛЕКЦИЯ</span><h1>Инвентарь</h1></div><div className="inventory-total"><span>Стоимость</span><strong>{money(inventoryValue)} ₽</strong></div></section>
        {inventory.length === 0 ? <div className="empty-state"><div className="empty-orbit"><Box size={54} /></div><h2>Здесь пока пусто</h2><p>Открой NFT-кейс — подарок появится здесь после остановки рулетки.</p><button className="primary-action" onClick={() => navigate('cases')}>Выбрать кейс <ChevronRight size={18} /></button></div> : <>
          <div className="inventory-toolbar"><span>{inventory.length} {inventory.length === 1 ? 'подарок' : 'подарков'}</span></div>
          <div className="inventory-grid">{inventory.map(item => <article className={`inventory-item gift-${item.gift.rarity}`} key={item.id}><span className="rarity-label">NFT GIFT</span><GiftArt gift={item.gift} /><h3>{item.gift.name}</h3><span>{money(item.gift.stars)} ★ · 1 ★ = {money(currentStarRate)} ₽</span><button disabled={sellMutation.isPending} onClick={async () => { try { await sellMutation.mutateAsync({ clientKey, itemId: item.id }); refresh(); notify(`${item.gift.name}: +${money(giftRub(item.gift))} ₽`) } catch { notify('Не удалось продать подарок') } }}>Продать за {money(giftRub(item.gift))} ₽</button></article>)}</div>
        </>}
      </div>}

      {tab === 'profile' && <div className="page profile-page">
        <section className="profile-hero"><div className="avatar"><User size={34} /></div><div><span className="eyebrow">ИГРОК NEBULA</span><h1>Космонавт</h1><span>Серверный профиль</span></div><span className="level">LVL 01</span></section>
        <section className="profile-stats"><div><span>Баланс</span><strong>{money(balance)} ₽</strong></div><div><span>NFT-подарков</span><strong>{inventory.length}</strong></div><div><span>Коллекция</span><strong>{money(inventoryValue)} ₽</strong></div></section>
        <section className="game-statistics"><div className="stats-heading"><div><span className="eyebrow">ЗА ВСЁ ВРЕМЯ</span><h2>Статистика игр</h2></div><History size={24} /></div><div className="stats-feature"><span>Лучший выигрыш</span><strong>{money(stats?.bestWin || 0)} ₽</strong><small>Максимальная выплата за раунд</small></div><div className="stats-grid"><div><span>Оборот</span><strong>{money(stats?.turnover || 0)} ₽</strong></div><div><span>Сыграно игр</span><strong>{stats?.games || 0}</strong></div><div><span>Выигрыши</span><strong>{stats?.wins || 0}</strong></div><div><span>Процент побед</span><strong>{stats?.games ? Math.round(stats.wins / stats.games * 100) : 0}%</strong></div></div><div className="favorite-game"><span><Gamepad2 size={20} /> Любимая игра</span><strong>{stats?.favoriteGame ? gameNames[stats.favoriteGame] : 'Пока нет игр'}</strong><small>{stats?.favoriteShare || 0}% всех ставок</small></div></section>
        <section className="bonus-panel"><div><GiftIcon size={30} /><span><strong>Ежедневный бонус</strong><small>От 25 до 100 ₽ каждые 24 часа</small></span></div><button onClick={claimBonus} disabled={bonusMutation.isPending || !!(lastBonus && Date.now() - lastBonus.getTime() < 86400000)}>{lastBonus && Date.now() - lastBonus.getTime() < 86400000 ? <><Check size={18} /> Получено</> : 'Забрать'}</button></section>
        <section className="profile-links"><button onClick={() => navigate('inventory')}><History size={22} /><span><strong>Моя NFT-коллекция</strong><small>Подарки и продажа предметов</small></span><ChevronRight size={20} /></button><button onClick={() => setGame('dice')}><CircleDollarSign size={22} /><span><strong>Мои лобби</strong><small>Создание и история игр в кости</small></span><ChevronRight size={20} /></button></section>
        <div className="demo-warning"><ShieldCheck size={20} /><p><strong>Игровая валюта</strong>Рубли виртуальные. NFT-подарки являются игровыми коллекционными предметами; вывод в Telegram и реальные платежи не подключены.</p></div>
      </div>}
    </main>

    <nav className="mobile-nav" aria-label="Основная навигация">{navItems.map(({ id, label, icon: Icon }) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => navigate(id)}><span><Icon size={21} />{id === 'inventory' && inventory.length > 0 && <b>{inventory.length}</b>}</span>{label}</button>)}</nav>

    {game && <Modal onClose={() => setGame(null)} label={game === 'rocket' ? 'Ракета' : game === 'upgrade' ? 'Апгрейд' : 'Лобби костей'} wide={game === 'dice'}>
      <div className="modal-heading"><span className="eyebrow">NEBULA ORIGINALS</span><h2>{game === 'rocket' ? 'Ракета' : game === 'upgrade' ? 'Апгрейд' : 'Кости · Лобби'}</h2></div>
      {game === 'rocket' ? <RocketGame {...common} /> : game === 'upgrade' ? <UpgradeGame {...common} /> : <DiceGame {...common} />}
    </Modal>}
    {activeCase && <CaseOpening data={activeCase} clientKey={clientKey} refresh={refresh} notify={notify} onClose={() => setActiveCase(null)} goInventory={() => navigate('inventory')} />}
    {toast && <div className="toast" role="status"><Check size={18} />{toast}</div>}
  </div>
}
