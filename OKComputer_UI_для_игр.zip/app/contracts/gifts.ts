export type Gift = {
  id: string
  name: string
  stars: number
  rub: number
  image: string
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
}

const gift = (id: string, name: string, stars: number, rarity: Gift['rarity'] = 'common'): Gift => ({
  id, name, stars, rub: Math.round(stars * 1.3), image: `/gifts/${id}.webp`, rarity,
})

export const gifts = [
  { id: 'cash', name: 'Рубли на баланс', stars: 0, rub: 0, image: '', rarity: 'common' as const },
  gift('candle', 'Свеча', 480),
  gift('ice-cream', 'Мороженое', 495),
  gift('snake', 'Змейка', 500),
  gift('cake', 'Торт', 579),
  gift('cupcake', 'Капкейк', 786),
  gift('rocket', 'Ракета', 540),
  gift('gingerbread', 'Пряник', 500),
  gift('jar', 'Банка Telegram', 579, 'rare'),
  gift('bouquet', 'Букет', 579, 'rare'),
  gift('heart-cats', 'Коты в сердце', 1613, 'rare'),
  gift('teddy', 'Розовый мишка', 3213, 'rare'),
  gift('candy-cane', 'Candy Cane', 450),
  gift('dragon', 'Зелёный дракон', 550, 'epic'),
  gift('diamond', 'Алмаз', 12225, 'epic'),
  gift('ring', 'Кольцо', 10671, 'epic'),
  gift('trophy', 'Кубок', 11539, 'epic'),
  gift('plum', 'Слива', 24393, 'legendary'),
  gift('black-cat', 'Чёрный кот', 26469, 'legendary'),
  gift('rose', 'Вечная роза', 2413, 'rare'),
  gift('perfume', 'Духи', 1360, 'rare'),
  gift('tamagotchi', 'Тамагочи', 505),
]

export const giftMap = Object.fromEntries(gifts.map(g => [g.id, g])) as Record<string, Gift>

export type CasePrize = { giftId: string; weight: number }
export type GameCase = {
  id: string
  name: string
  price: number
  subtitle: string
  accent: string
  prizes: CasePrize[]
}

export const gameCases: GameCase[] = [
  { id: 'micro', name: 'Звёздная пыль', price: 39, subtitle: 'NFT или рубли', accent: 'blue', prizes: [
    { giftId: 'cash', weight: 96 }, { giftId: 'candy-cane', weight: 2 }, { giftId: 'candle', weight: 1.5 }, { giftId: 'cake', weight: 0.5 },
  ]},
  { id: 'orbit', name: 'Малая орбита', price: 50, subtitle: 'Быстрый дроп', accent: 'lime', prizes: [
    { giftId: 'cash', weight: 95 }, { giftId: 'ice-cream', weight: 2.5 }, { giftId: 'cupcake', weight: 2 }, { giftId: 'heart-cats', weight: 0.5 },
  ]},
  { id: 'comet', name: 'Комета', price: 69, subtitle: 'Смешанные призы', accent: 'violet', prizes: [
    { giftId: 'cash', weight: 94 }, { giftId: 'cake', weight: 3 }, { giftId: 'rocket', weight: 2 }, { giftId: 'teddy', weight: 1 },
  ]},
  { id: 'starter', name: 'Первый контакт', price: 749, subtitle: 'Тёплые подарки', accent: 'blue', prizes: [
    { giftId: 'candle', weight: 64.8 }, { giftId: 'ice-cream', weight: 25 }, { giftId: 'cake', weight: 7 },
    { giftId: 'heart-cats', weight: 2.7 }, { giftId: 'teddy', weight: 0.45 }, { giftId: 'diamond', weight: 0.05 },
  ]},
  { id: 'neon', name: 'Неоновый', price: 1499, subtitle: 'Яркая коллекция', accent: 'lime', prizes: [
    { giftId: 'cake', weight: 45 }, { giftId: 'cupcake', weight: 34 }, { giftId: 'heart-cats', weight: 14 },
    { giftId: 'teddy', weight: 5.9 }, { giftId: 'ring', weight: 1.05 }, { giftId: 'black-cat', weight: 0.05 },
  ]},
  { id: 'party', name: 'Вечеринка', price: 3299, subtitle: 'Сладкий риск', accent: 'coral', prizes: [
    { giftId: 'cupcake', weight: 40 }, { giftId: 'heart-cats', weight: 34 }, { giftId: 'teddy', weight: 18 },
    { giftId: 'ring', weight: 6.9 }, { giftId: 'diamond', weight: 1 }, { giftId: 'plum', weight: 0.1 },
  ]},
  { id: 'rare', name: 'Редкий сигнал', price: 8499, subtitle: 'Коллекционные NFT', accent: 'violet', prizes: [
    { giftId: 'teddy', weight: 48 }, { giftId: 'ring', weight: 31 }, { giftId: 'trophy', weight: 15 },
    { giftId: 'diamond', weight: 4.95 }, { giftId: 'plum', weight: 1 }, { giftId: 'black-cat', weight: 0.05 },
  ]},
  { id: 'galaxy', name: 'Галактический', price: 24999, subtitle: 'За пределами орбиты', accent: 'gold', prizes: [
    { giftId: 'ring', weight: 45 }, { giftId: 'trophy', weight: 31 }, { giftId: 'diamond', weight: 17 },
    { giftId: 'plum', weight: 5.9 }, { giftId: 'black-cat', weight: 1 }, { giftId: 'rose', weight: 0.1 },
  ]},
  { id: 'black-hole', name: 'Чёрная дыра', price: 74999, subtitle: 'Только легенды', accent: 'black', prizes: [
    { giftId: 'diamond', weight: 48 }, { giftId: 'plum', weight: 32 }, { giftId: 'black-cat', weight: 17 },
    { giftId: 'trophy', weight: 2.8 }, { giftId: 'rose', weight: 0.18 }, { giftId: 'teddy', weight: 0.02 },
  ]},
]

export const caseMap = Object.fromEntries(gameCases.map(c => [c.id, c])) as Record<string, GameCase>

export function pickCasePrize(caseId: string): Gift {
  const gameCase = caseMap[caseId]
  if (!gameCase) throw new Error('CASE_NOT_FOUND')
  const total = gameCase.prizes.reduce((sum, p) => sum + p.weight, 0)
  let roll = Math.random() * total
  for (const prize of gameCase.prizes) {
    roll -= prize.weight
    if (roll <= 0) return giftMap[prize.giftId]
  }
  return giftMap[gameCase.prizes[0].giftId]
}
