import { eq } from 'drizzle-orm'
import { getDb } from './queries/connection'
import { appSettings, paymentRequests, players } from '@db/schema'

const token = process.env.BOT_TOKEN || ''
const adminId = Number(process.env.ADMIN_TELEGRAM_ID || 0)
const api = `https://api.telegram.org/bot${token}`
const pending = new Map<number, { action: string; playerId?: number }>()

async function call(method: string, body: Record<string, unknown>) {
  const response = await fetch(`${api}/${method}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
  const result = await response.json() as { ok: boolean; description?: string; result?: any }
  if (!result.ok) throw new Error(result.description || `Telegram ${method} failed`)
  return result.result
}

const adminKeyboard = { inline_keyboard: [
  [{ text: '👥 Пользователи', callback_data: 'users:0' }, { text: '🚫 Чёрный список', callback_data: 'blacklist:0' }],
  [{ text: '⭐ Курс Stars', callback_data: 'rate:stars_rate' }, { text: '🪙 Курс GRAM', callback_data: 'rate:gram_rate' }],
  [{ text: '📥 Пополнения', callback_data: 'requests:deposit' }, { text: '📤 Заявки на вывод', callback_data: 'requests:withdraw' }],
] }

async function userList(chatId: number, blacklist: boolean, page: number) {
  const rows = await getDb().select().from(players).orderBy(players.id).limit(100)
  const filtered = rows.filter(row => blacklist ? row.blacklisted : !row.blacklisted)
  const items = filtered.slice(page * 8, page * 8 + 8)
  const buttons = items.map(row => [{ text: `${row.blacklisted ? '🚫 ' : ''}${row.name} · ${row.balance.toFixed(2)} ₽`, callback_data: blacklist ? `unban:${row.id}` : `user:${row.id}` }])
  await call('sendMessage', { chat_id: chatId, text: blacklist ? 'Чёрный список. Нажмите на пользователя, чтобы разблокировать.' : `Пользователи: ${filtered.length}. Выберите игрока:`, reply_markup: { inline_keyboard: buttons.length ? buttons : [[{ text: '← Назад', callback_data: 'admin' }]] } })
}

async function handleCallback(query: any) {
  const chatId = query.message.chat.id
  const fromId = query.from.id
  await call('answerCallbackQuery', { callback_query_id: query.id })
  if (fromId !== adminId) return
  const [action, value] = query.data.split(':') as string[]
  if (action === 'admin') return call('sendMessage', { chat_id: chatId, text: 'Админ-панель NebulaBet', reply_markup: adminKeyboard })
  if (action === 'users') return userList(chatId, false, Number(value))
  if (action === 'blacklist') return userList(chatId, true, Number(value))
  if (action === 'rate') {
    pending.set(fromId, { action: query.data })
    return call('sendMessage', { chat_id: chatId, text: `Введите новый курс ${value === 'stars_rate' ? '1 Stars' : '1 GRAM'} в рублях:` })
  }
  if (action === 'requests') {
    const rows = await getDb().select().from(paymentRequests).where(eq(paymentRequests.type, value as 'deposit' | 'withdraw')).limit(30)
    return call('sendMessage', { chat_id: chatId, text: rows.length ? rows.map(row => `#${row.id} · ${row.amount} ₽ · ${row.status}`).join('\n') : 'Заявок пока нет.' })
  }
  if (action === 'ban' || action === 'unban') {
    await getDb().update(players).set({ blacklisted: action === 'ban' ? 1 : 0 }).where(eq(players.id, Number(value)))
    return call('sendMessage', { chat_id: chatId, text: action === 'ban' ? 'Пользователь добавлен в чёрный список.' : 'Пользователь разблокирован.', reply_markup: adminKeyboard })
  }
  if (action === 'balance') {
    pending.set(fromId, { action: query.data, playerId: Number(value) })
    return call('sendMessage', { chat_id: chatId, text: 'Введите сумму со знаком. Например: +500 или -100:' })
  }
  if (action === 'user') {
    const player = await getDb().query.players.findFirst({ where: eq(players.id, Number(value)) })
    if (!player) return
    return call('sendMessage', { chat_id: chatId, text: `ID: ${player.id}\nTelegram: ${player.clientKey}\nИмя: ${player.name}\nБаланс: ${player.balance.toFixed(2)} ₽`, reply_markup: { inline_keyboard: [[{ text: '＋/− Баланс', callback_data: `balance:${player.id}` }], [{ text: '🚫 В чёрный список', callback_data: `ban:${player.id}` }], [{ text: '← Назад', callback_data: 'admin' }]] } })
  }
}

async function handleMessage(message: any) {
  const chatId = message.chat.id
  const fromId = message.from.id
  const text = String(message.text || '')
  if (text.startsWith('/admin')) {
    if (fromId !== adminId) return call('sendMessage', { chat_id: chatId, text: 'Команда доступна только администратору.' })
    return call('sendMessage', { chat_id: chatId, text: 'Админ-панель NebulaBet', reply_markup: adminKeyboard })
  }
  if (pending.has(fromId) && fromId === adminId) {
    const task = pending.get(fromId)!
    pending.delete(fromId)
    const amount = Number(text.replace(',', '.'))
    if (!Number.isFinite(amount)) return call('sendMessage', { chat_id: chatId, text: 'Нужно ввести число.' })
    if (task.action.startsWith('rate:')) {
      const key = task.action.split(':')[1]
      if (amount <= 0) return call('sendMessage', { chat_id: chatId, text: 'Курс должен быть больше нуля.' })
      await getDb().insert(appSettings).values({ key, value: String(amount) }).onDuplicateKeyUpdate({ set: { value: String(amount) } })
      return call('sendMessage', { chat_id: chatId, text: `Новый курс сохранён: ${amount} ₽. Мини-приложение уже использует его.`, reply_markup: adminKeyboard })
    }
    if (task.action.startsWith('balance:') && task.playerId) {
      const player = await getDb().query.players.findFirst({ where: eq(players.id, task.playerId) })
      if (player) await getDb().update(players).set({ balance: Math.max(0, player.balance + amount) }).where(eq(players.id, player.id))
      return call('sendMessage', { chat_id: chatId, text: 'Баланс обновлён в мини-приложении.', reply_markup: adminKeyboard })
    }
  }
  if (!text.startsWith('/start')) return
  const clientKey = `tg:${fromId}`
  const db = getDb()
  let player = await db.query.players.findFirst({ where: eq(players.clientKey, clientKey) })
  if (!player) {
    await db.insert(players).values({ clientKey, name: message.from.first_name || 'Космонавт', username: message.from.username || null })
    player = await db.query.players.findFirst({ where: eq(players.clientKey, clientKey) })
  }
  if (player?.blacklisted) return call('sendMessage', { chat_id: chatId, text: 'Вы находитесь в чёрном списке.' })
  const appUrl = process.env.MINI_APP_URL || process.env.APP_URL
  const replyMarkup = appUrl ? { inline_keyboard: [[{ text: '🚀 Играть', web_app: { url: appUrl } }]] } : undefined
  const caption = '<a href="' + (appUrl || 'https://t.me') + '">NebulaBet</a> — твоя игра среди звёзд.\n\n🎁 NFT-кейсы и подарки\n🚀 Общие раунды ракеты\n🎲 Лобби с игроками и ботом\n⚡ Апгрейд до ×50'
  if (appUrl) {
    try {
      const data = await call('sendAnimation', { chat_id: chatId, animation: process.env.NEBULA_AD_URL || `${appUrl.replace(/\/$/, '')}/nebula-ad.mp4`, caption, parse_mode: 'HTML', reply_markup: replyMarkup })
      return data
    } catch { /* fall back to text if the animation URL is unavailable */ }
  }
  return call('sendMessage', { chat_id: chatId, text: 'NebulaBet — игры среди звёзд. Открой мини-приложение и начни играть!', reply_markup: replyMarkup })
}

export async function startTelegramBot() {
  if (!token || !adminId) return
  let offset = 0
  const poll = async () => {
    try {
      const updates = await call('getUpdates', { offset, timeout: 25, allowed_updates: ['message', 'callback_query'] })
      for (const update of updates) {
        offset = update.update_id + 1
        if (update.message) await handleMessage(update.message)
        if (update.callback_query) await handleCallback(update.callback_query)
      }
    } catch (error) {
      console.error('Telegram polling:', error instanceof Error ? error.message : error)
      await new Promise(resolve => setTimeout(resolve, 5000))
    }
    setTimeout(poll, 0)
  }
  void poll()
}
