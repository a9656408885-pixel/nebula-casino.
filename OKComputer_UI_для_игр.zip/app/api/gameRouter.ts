import { z } from 'zod'
import { and, desc, eq, or } from 'drizzle-orm'
import { TRPCError } from '@trpc/server'
import { createRouter, publicQuery } from './middleware'
import { getDb } from './queries/connection'
import { appSettings, crashBets, crashRounds, diceLobbies, gameEvents, inventoryItems, players } from '@db/schema'
import { caseMap, giftMap, pickCasePrize } from '@contracts/gifts'

const keySchema = z.string().min(6).max(80)
const betSchema = z.number().min(10).max(1000000)

async function ensurePlayer(clientKey: string) {
  const db = getDb()
  let player = await db.query.players.findFirst({ where: eq(players.clientKey, clientKey) })
  if (!player) {
    await db.insert(players).values({ clientKey })
    player = await db.query.players.findFirst({ where: eq(players.clientKey, clientKey) })
  }
  if (!player) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Не удалось создать профиль' })
  if (player.blacklisted) throw new TRPCError({ code: 'FORBIDDEN', message: 'Вы находитесь в чёрном списке' })
  return player
}

async function giftValue(gift: typeof giftMap[string]) {
  if (gift.id === 'cash') return gift.rub
  const row = await getDb().query.appSettings.findFirst({ where: eq(appSettings.key, 'stars_rate') })
  return Math.round(gift.stars * Number(row?.value || 1.3))
}

async function state(clientKey: string) {
  const player = await ensurePlayer(clientKey)
  const db = getDb()
  const [rows, events, rateRows] = await Promise.all([
    db.select().from(inventoryItems).where(eq(inventoryItems.playerId, player.id)).orderBy(desc(inventoryItems.id)),
    db.select().from(gameEvents).where(eq(gameEvents.playerId, player.id)).orderBy(desc(gameEvents.id)).limit(1000),
    db.select().from(appSettings),
  ])
  const byGame = events.reduce<Record<string, { games: number; bet: number }>>((acc, event) => {
    acc[event.game] ||= { games: 0, bet: 0 }
    acc[event.game].games += 1
    acc[event.game].bet += event.bet
    return acc
  }, {})
  const favorite = Object.entries(byGame).sort((a, b) => b[1].games - a[1].games)[0]
  return {
    player: { id: player.id, name: player.name, balance: player.balance, lastBonus: player.lastBonus },
    inventory: rows.map(row => ({ id: row.id, gift: giftMap[row.giftId], createdAt: row.createdAt })).filter(row => row.gift),
    rates: {
      stars: Number(rateRows.find(row => row.key === 'stars_rate')?.value || 1.3),
      gram: Number(rateRows.find(row => row.key === 'gram_rate')?.value || 150),
    },
    stats: {
      games: events.length,
      wins: events.filter(event => event.payout > event.bet).length,
      turnover: events.reduce((sum, event) => sum + event.bet, 0),
      bestWin: events.reduce((best, event) => Math.max(best, event.payout), 0),
      favoriteGame: favorite?.[0] || null,
      favoriteShare: favorite && events.length ? Math.round(favorite[1].games / events.length * 100) : 0,
    },
  }
}

async function lobbyView(lobby: typeof diceLobbies.$inferSelect) {
  const db = getDb()
  const [creator, opponent] = await Promise.all([
    db.query.players.findFirst({ where: eq(players.id, lobby.creatorId) }),
    lobby.opponentId ? db.query.players.findFirst({ where: eq(players.id, lobby.opponentId) }) : null,
  ])
  return { ...lobby, creatorName: creator?.name || 'Игрок', opponentName: lobby.isBot ? 'Nebula Bot' : opponent?.name || null }
}

async function currentCrashRound() {
  const db = getDb()
  let [round] = await db.select().from(crashRounds).orderBy(desc(crashRounds.id)).limit(1)
  const now = Date.now()
  if (!round || (round.status === 'crashed' && now - round.startsAt.getTime() > 5000)) {
    const crashPoint = Math.max(1.05, 0.98 / (1 - Math.random() * 0.97))
    const [{ id }] = await db.insert(crashRounds).values({ crashPoint, startsAt: new Date(now + 8000) }).$returningId()
    round = (await db.query.crashRounds.findFirst({ where: eq(crashRounds.id, id) }))!
  }
  if (round.status === 'betting' && now >= round.startsAt.getTime()) {
    await db.update(crashRounds).set({ status: 'running', startsAt: new Date(now) }).where(eq(crashRounds.id, round.id))
    round = { ...round, status: 'running', startsAt: new Date(now) }
  }
  const multiplier = round.status === 'running' ? Math.exp(Math.max(0, now - round.startsAt.getTime()) * 0.000385) : 1
  if (round.status === 'running' && multiplier >= round.crashPoint) {
    await db.update(crashRounds).set({ status: 'crashed' }).where(eq(crashRounds.id, round.id))
    const pending = await db.select().from(crashBets).where(and(eq(crashBets.roundId, round.id), eq(crashBets.payout, 0)))
    if (pending.length) await db.insert(gameEvents).values(pending.map(bet => ({ playerId: bet.playerId, game: 'rocket', bet: bet.bet, payout: 0 })))
    round = { ...round, status: 'crashed' }
  }
  return { round, multiplier: round.status === 'crashed' ? round.crashPoint : multiplier }
}

async function crashView(playerId: number) {
  const { round, multiplier } = await currentCrashRound()
  const bets = await getDb().select().from(crashBets).where(eq(crashBets.roundId, round.id)).orderBy(desc(crashBets.id))
  const names = await getDb().select().from(players)
  return {
    roundId: round.id, status: round.status, multiplier, startsAt: round.startsAt,
    bets: bets.map(bet => ({ ...bet, name: names.find(player => player.id === bet.playerId)?.name || 'Игрок' })),
    myBet: bets.find(bet => bet.playerId === playerId) || null,
  }
}

export const gameRouter = createRouter({
  state: publicQuery.input(z.object({ clientKey: keySchema })).query(({ input }) => state(input.clientKey)),

  upgrade: publicQuery.input(z.object({ clientKey: keySchema, bet: betSchema, multiplier: z.number().min(2).max(50) })).mutation(async ({ input }) => {
    const db = getDb()
    return db.transaction(async tx => {
      const [player] = await tx.select().from(players).where(eq(players.clientKey, input.clientKey)).for('update')
      if (!player || player.balance < input.bet) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Недостаточно средств' })
      const chance = 0.95 / input.multiplier
      const win = Math.random() < chance
      const balance = Math.round((player.balance - input.bet + (win ? input.bet * input.multiplier : 0)) * 100) / 100
      await tx.update(players).set({ balance }).where(eq(players.id, player.id))
      await tx.insert(gameEvents).values({ playerId: player.id, game: 'upgrade', bet: input.bet, payout: win ? input.bet * input.multiplier : 0 })
      return { win, chance, balance }
    })
  }),

  upgradeItem: publicQuery.input(z.object({ clientKey: keySchema, itemId: z.number(), multiplier: z.number().min(2).max(50), targetId: z.string() })).mutation(async ({ input }) => {
    const target = giftMap[input.targetId]
    if (!target) throw new TRPCError({ code: 'NOT_FOUND', message: 'Целевой подарок не найден' })
    const db = getDb()
    return db.transaction(async tx => {
      const [player] = await tx.select().from(players).where(eq(players.clientKey, input.clientKey)).for('update')
      const [item] = await tx.select().from(inventoryItems).where(eq(inventoryItems.id, input.itemId)).for('update')
      const source = item ? giftMap[item.giftId] : null
      if (!player || !item || item.playerId !== player.id || !source) throw new TRPCError({ code: 'NOT_FOUND', message: 'Подарок не найден' })
      const chance = 0.95 / input.multiplier
      const win = Math.random() < chance
      await tx.delete(inventoryItems).where(eq(inventoryItems.id, item.id))
      if (win) await tx.insert(inventoryItems).values({ playerId: player.id, giftId: target.id })
      await tx.insert(gameEvents).values({ playerId: player.id, game: 'upgrade', bet: await giftValue(source), payout: win ? await giftValue(target) : 0 })
      return { win, chance, target }
    })
  }),

  openCase: publicQuery.input(z.object({ clientKey: keySchema, caseId: z.string() })).mutation(async ({ input }) => {
    const gameCase = caseMap[input.caseId]
    if (!gameCase) throw new TRPCError({ code: 'NOT_FOUND', message: 'Кейс не найден' })
    const db = getDb()
    return db.transaction(async tx => {
      const [player] = await tx.select().from(players).where(eq(players.clientKey, input.clientKey)).for('update')
      if (!player || player.balance < gameCase.price) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Недостаточно средств' })
      let prize = pickCasePrize(input.caseId)
      if (prize.id === 'cash') {
        const amounts = input.caseId === 'micro' ? [5, 8, 12, 18, 25, 32] : input.caseId === 'orbit' ? [7, 12, 18, 25, 35, 45] : [10, 15, 22, 32, 45, 60]
        prize = { ...prize, rub: amounts[Math.floor(Math.random() * amounts.length)], name: `${amounts[0]} ₽` }
        prize.name = `${prize.rub} ₽ на баланс`
      }
      const balance = Math.round((player.balance - gameCase.price + (prize.id === 'cash' ? prize.rub : 0)) * 100) / 100
      await tx.update(players).set({ balance }).where(eq(players.id, player.id))
      let id = 0
      if (prize.id !== 'cash') {
        const inserted = await tx.insert(inventoryItems).values({ playerId: player.id, giftId: prize.id }).$returningId()
        id = inserted[0].id
      }
      await tx.insert(gameEvents).values({ playerId: player.id, game: 'cases', bet: gameCase.price, payout: await giftValue(prize) })
      return { prize, balance, itemId: id }
    })
  }),

  sellItem: publicQuery.input(z.object({ clientKey: keySchema, itemId: z.number() })).mutation(async ({ input }) => {
    const db = getDb()
    return db.transaction(async tx => {
      const [player] = await tx.select().from(players).where(eq(players.clientKey, input.clientKey)).for('update')
      const [item] = await tx.select().from(inventoryItems).where(eq(inventoryItems.id, input.itemId)).for('update')
      const prize = item ? giftMap[item.giftId] : null
      if (!player || !item || item.playerId !== player.id || !prize) throw new TRPCError({ code: 'NOT_FOUND', message: 'Предмет не найден' })
      const balance = Math.round((player.balance + await giftValue(prize)) * 100) / 100
      await tx.delete(inventoryItems).where(eq(inventoryItems.id, item.id))
      await tx.update(players).set({ balance }).where(eq(players.id, player.id))
      return { balance, prize }
    })
  }),

  bonus: publicQuery.input(z.object({ clientKey: keySchema })).mutation(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    if (player.lastBonus && Date.now() - player.lastBonus.getTime() < 86400000) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Бонус уже получен' })
    const amount = [25, 50, 75, 100][Math.floor(Math.random() * 4)]
    const balance = player.balance + amount
    await getDb().update(players).set({ balance, lastBonus: new Date() }).where(eq(players.id, player.id))
    return { amount, balance, lastBonus: new Date() }
  }),

  rocketStart: publicQuery.input(z.object({ clientKey: keySchema, bet: betSchema })).mutation(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    const { round } = await currentCrashRound()
    if (round.status !== 'betting') throw new TRPCError({ code: 'BAD_REQUEST', message: 'Дождитесь следующего раунда' })
    const existing = await getDb().query.crashBets.findFirst({ where: and(eq(crashBets.roundId, round.id), eq(crashBets.playerId, player.id)) })
    if (existing) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Ставка уже сделана' })
    if (player.balance < input.bet) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Недостаточно средств' })
    const balance = player.balance - input.bet
    const db = getDb()
    await db.update(players).set({ balance }).where(eq(players.id, player.id))
    await db.insert(crashBets).values({ roundId: round.id, playerId: player.id, bet: input.bet })
    return { roundId: round.id, startedAt: round.startsAt, balance }
  }),

  rocketStatus: publicQuery.input(z.object({ clientKey: keySchema, roundId: z.number().optional() })).query(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    return crashView(player.id)
  }),

  rocketCashout: publicQuery.input(z.object({ clientKey: keySchema, roundId: z.number() })).mutation(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    const { round, multiplier } = await currentCrashRound()
    if (round.id !== input.roundId || round.status !== 'running') throw new TRPCError({ code: 'BAD_REQUEST', message: 'Раунд уже завершён' })
    const db = getDb()
    return db.transaction(async tx => {
      const [bet] = await tx.select().from(crashBets).where(and(eq(crashBets.roundId, round.id), eq(crashBets.playerId, player.id))).for('update')
      const [owner] = await tx.select().from(players).where(eq(players.id, player.id)).for('update')
      if (!bet || !owner || bet.cashoutAt) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Выигрыш уже забран' })
      const payout = Math.floor(bet.bet * multiplier * 100) / 100
      const balance = Math.round((owner.balance + payout) * 100) / 100
      await tx.update(crashBets).set({ cashoutAt: multiplier, payout }).where(eq(crashBets.id, bet.id))
      await tx.update(players).set({ balance }).where(eq(players.id, owner.id))
      await tx.insert(gameEvents).values({ playerId: owner.id, game: 'rocket', bet: bet.bet, payout })
      return { balance, payout, multiplier }
    })
  }),

  diceLobbies: publicQuery.input(z.object({ clientKey: keySchema })).query(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    const rows = await getDb().select().from(diceLobbies).where(or(eq(diceLobbies.status, 'waiting'), eq(diceLobbies.creatorId, player.id), eq(diceLobbies.opponentId, player.id))).orderBy(desc(diceLobbies.id)).limit(30)
    return Promise.all(rows.map(lobbyView))
  }),

  createDiceLobby: publicQuery.input(z.object({ clientKey: keySchema, bet: betSchema })).mutation(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    if (player.balance < input.bet) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Недостаточно средств' })
    const balance = player.balance - input.bet
    const db = getDb()
    await db.update(players).set({ balance }).where(eq(players.id, player.id))
    const [{ id }] = await db.insert(diceLobbies).values({ creatorId: player.id, bet: input.bet }).$returningId()
    const lobby = await db.query.diceLobbies.findFirst({ where: eq(diceLobbies.id, id) })
    return { lobby: await lobbyView(lobby!), balance }
  }),

  joinDiceLobby: publicQuery.input(z.object({ clientKey: keySchema, lobbyId: z.number() })).mutation(async ({ input }) => {
    await ensurePlayer(input.clientKey)
    const db = getDb()
    return db.transaction(async tx => {
      const [lobby] = await tx.select().from(diceLobbies).where(eq(diceLobbies.id, input.lobbyId)).for('update')
      const [opponent] = await tx.select().from(players).where(eq(players.clientKey, input.clientKey)).for('update')
      const [creator] = await tx.select().from(players).where(eq(players.id, lobby?.creatorId || 0)).for('update')
      if (!lobby || lobby.status !== 'waiting') throw new TRPCError({ code: 'BAD_REQUEST', message: 'Лобби уже закрыто' })
      if (!opponent || !creator || lobby.creatorId === opponent.id) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Нельзя войти в своё лобби' })
      if (opponent.balance < lobby.bet) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Недостаточно средств' })
      const creatorRoll = 1 + Math.floor(Math.random() * 6)
      const opponentRoll = 1 + Math.floor(Math.random() * 6)
      const winnerId = creatorRoll === opponentRoll ? null : creatorRoll > opponentRoll ? creator.id : opponent.id
      await tx.update(players).set({ balance: opponent.balance - lobby.bet + (winnerId === opponent.id ? lobby.bet * 1.9 : opponentRoll === creatorRoll ? lobby.bet : 0) }).where(eq(players.id, opponent.id))
      if (winnerId === creator.id || creatorRoll === opponentRoll) await tx.update(players).set({ balance: creator.balance + (winnerId === creator.id ? lobby.bet * 1.9 : lobby.bet) }).where(eq(players.id, creator.id))
      await tx.update(diceLobbies).set({ opponentId: opponent.id, status: 'finished', creatorRoll, opponentRoll, winnerId }).where(eq(diceLobbies.id, lobby.id))
      await tx.insert(gameEvents).values([
        { playerId: creator.id, game: 'dice', bet: lobby.bet, payout: winnerId === creator.id ? lobby.bet * 1.9 : creatorRoll === opponentRoll ? lobby.bet : 0 },
        { playerId: opponent.id, game: 'dice', bet: lobby.bet, payout: winnerId === opponent.id ? lobby.bet * 1.9 : creatorRoll === opponentRoll ? lobby.bet : 0 },
      ])
      const updated = await tx.query.diceLobbies.findFirst({ where: eq(diceLobbies.id, lobby.id) })
      return { lobby: await lobbyView(updated!) }
    })
  }),

  joinDiceBot: publicQuery.input(z.object({ clientKey: keySchema, lobbyId: z.number() })).mutation(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    const db = getDb()
    return db.transaction(async tx => {
      const [lobby] = await tx.select().from(diceLobbies).where(eq(diceLobbies.id, input.lobbyId)).for('update')
      const [creator] = await tx.select().from(players).where(eq(players.id, player.id)).for('update')
      if (!lobby || lobby.creatorId !== player.id || lobby.status !== 'waiting') throw new TRPCError({ code: 'BAD_REQUEST', message: 'Лобби уже закрыто' })
      const creatorRoll = 1 + Math.floor(Math.random() * 6)
      const opponentRoll = 1 + Math.floor(Math.random() * 6)
      const creatorWon = creatorRoll > opponentRoll
      const payout = creatorRoll === opponentRoll ? lobby.bet : creatorWon ? lobby.bet * 1.9 : 0
      await tx.update(players).set({ balance: creator.balance + payout }).where(eq(players.id, creator.id))
      await tx.update(diceLobbies).set({ status: 'finished', creatorRoll, opponentRoll, winnerId: creatorWon ? creator.id : null, isBot: 1 }).where(eq(diceLobbies.id, lobby.id))
      await tx.insert(gameEvents).values({ playerId: creator.id, game: 'dice', bet: lobby.bet, payout })
      const updated = await tx.query.diceLobbies.findFirst({ where: eq(diceLobbies.id, lobby.id) })
      return { lobby: await lobbyView(updated!) }
    })
  }),

  cancelDiceLobby: publicQuery.input(z.object({ clientKey: keySchema, lobbyId: z.number() })).mutation(async ({ input }) => {
    const player = await ensurePlayer(input.clientKey)
    const lobby = await getDb().query.diceLobbies.findFirst({ where: eq(diceLobbies.id, input.lobbyId) })
    if (!lobby || lobby.creatorId !== player.id || lobby.status !== 'waiting') throw new TRPCError({ code: 'BAD_REQUEST', message: 'Лобби нельзя отменить' })
    const balance = player.balance + lobby.bet
    await getDb().update(diceLobbies).set({ status: 'cancelled' }).where(eq(diceLobbies.id, lobby.id))
    await getDb().update(players).set({ balance }).where(eq(players.id, player.id))
    return { balance }
  }),
})
